<!--
####////////////////|||\\\\\\\\\\\\\\\\\
####////                            \\\\
####////     (Game.Data.Config)     \\\\
####////  Admin@GameDataConfig.com  \\\\
####////   www.GAMEDATACONFIG.com   \\\\
####//// |Addons|GUI|Mods|Websites| \\\\
####////                            \\\\
####////////////////|||\\\\\\\\\\\\\\\\\
--!>
<html>
<head>
<title>License Key Generator - Game.Data.Config</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/main.css">
<script src='js/jquery.js'></script>
<script src="js/FileSaver.js"></script>
<script>
function saveDynamicDataToFile() {
var userInput = document.getElementById("myText").value;
			
var blob = new Blob([userInput], { type: "text/plain;charset=utf-8" });
saveAs(blob, "LicenseKeys.txt");
        }

</script>
<script type='text/javascript'>
var countselect='';
var $lcl,$ucl,$nl,$sl=0;
	 $(document).ready(function(){
	 var sds = document.getElementById("dum");
     if(sds == null){

     }
     var sdss = document.getElementById("dumdiv");
     if(sdss == null){

         document.getElementById("content").style.visibility="hidden";
     }    
	 $('.ckbox').click(function() {
		  $ckidd=$(this).attr('id');
		  if($(this).attr("checked")==true)
		  {
			   $("#"+$ckidd).val($ckidd);
		  }
		  else
		  {
			   $("#"+$ckidd).val(0)
			   if ($ckidd=="lowlen") {$lcl=0; }
			   if ($ckidd=="uplen") {$ucl=0;}
			   if ($ckidd=="nolen") {$nl=0;}
			   if ($ckidd=="symlen") {$sl=0;}
		  }	
	 });	
});
function submitt()
{
	 var chkval = [];
	 $.each($("input:checked"), function(){            
		   chkval.push($(this).val());
	 });
	 var countChecked = function() {
	 countselect = $( "input:checked" ).length;
	 };
	 countChecked();
	 if (countselect==0) {
		  $('#texarea').slideUp('slow');
		  alert("Select atleast one option");		  
	 }
	 var num =$("#mlen").val();
	 var division = num/countselect;	
	 var testarray=new Array("lowlen","uplen","nolen","symlen");
	 for(var i=0;i<=countselect;i++)
	 {
	   if (chkval[i]=="lowlen") {$lcl=division;}
	   if (chkval[i]=="uplen") {$ucl=division;}
	   if (chkval[i]=="nolen") {$nl=division;}
	   if (chkval[i]=="symlen") {$sl=division;}
	 }
	 var one = chkval[0];
	 $len=$("#mlen").val();	
	 if ($len!='') {		  	 
		  if(countselect!=0)
		  {
		  $('#err_msg').html("<font color='white'>");
			   $.post("generator.php","length="+$len+"&lowlen="+$lcl+"&uplen="+$ucl+"&nolen="+$nl+"&symlen="+$sl,function(resp){	   
					$('#err_msg').html("");
					$('#texarea').slideDown('slow');	
					$('#texarea').html(resp);          
			   });    
		  }
	 }
	 else{
		  alert("Check Key Length");
	 }
}
function isnumeric(idd)
{
	 $data=$('#'+idd).val();
	 if($data!="")
	 {
		if($data.match('^(0|[1-9][0-9]*)$'))
		{
			 return true;
		}
		else
		{ 
			 $('#'+idd).val("");
			 return false;
		} 
	 } 
}
function checknum(vv)
{
	 var dat = vv.value;
        if (dat>12 || dat<6) {
            alert("Check Key Length");
            vv.value='';
        }
		
}
</script>
<style>
.slidecontainer {
  width: 35%;
}

.slider {
  -webkit-appearance: none;
  width: 100%;
  height: 25px;
  background: #FFF;
  outline: none;
  opacity: 0.7;
  -webkit-transition: .2s;
  transition: opacity .2s;
}

.slider:hover {
  opacity: 1;
}

.slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 25px;
  height: 25px;
  background: #ffa700;
  cursor: pointer;
}

.slider::-moz-range-thumb {
  width: 25px;
  height: 25px;
  background: #ffa700;
  cursor: pointer;
}
</style>
	 </head>
	 <body>
		  <div class='resp_code frms'>
	 <center><b>[Lience Key Generator]</b></center><br>
<div align='center' id='content'>
	<font color="#FFF">[Length of License Key: 6 - 12] <BR><BR></font>


 
<div class="slidecontainer">
  <input type="range" min="6" max="12" value="16" class="slider" id="mlen" onkeyup="isnumeric('mlen')" onblur='checknum(this)'>
  <p><font color="#FFFFFF">[Key Length: <span id="demo"></span>]</p></font>
</div>

<script>
var slider = document.getElementById("mlen");
var output = document.getElementById("demo");
output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
}
</script>

	 <center>

  <div>
		  <div style='width:55%;'>
			  <input name="alpha" id='lowlen' value="lowlen" type="checkbox" checked class='ckbox' checked>
		  </div>
</div>
		  <div style='width:55%;'>
	
		  <div>
			 <input name="numeric" id='nolen' value="nolen" type="checkbox" class='ckbox' checked>
		  </div>
	 </div>
	
		
 	
	 <div id='err_msg' class='error'></div>
<center>
 <div style='width:100%;'>
	<br>
	 <input  type="button" class="button primary" value="Generate" onclick="submitt()" class="blue_button" />
	 <div class='texarea' id='texarea'></div> 
	 <input name="generate" value="true" type="hidden">

</div><br>
<div align='center' style="font-size: 14px;color: #FFF;" id="dumdiv">
<a href="https://www.gamedataconfig.com" target="_blank" id="dum" style="font-size: 14px;color: #FFF;text-decoration:none;color: #FFF;">Copyright &copy; 2021 www.GameDataConfig.com</a>
</div>
</div>
	 </body>
</html>



