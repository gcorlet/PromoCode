  <footer class="footer">
      <div class="container">
   <p class="text-muted"><center>Copyright &copy; <?php
echo date("Y");
?> www.GameDataConfig.com</p>
      </div>
  </footer>
</div>

    <!-- Bootstrap --> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>  
    
    <!--DataTables-->
    <script src="assets/plugins/datatables/datatables.min.js"></script>

  </body>
</html>