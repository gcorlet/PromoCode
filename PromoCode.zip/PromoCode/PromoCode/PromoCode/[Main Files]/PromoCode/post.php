<?php
session_start();
include "config.php";
?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">

                    <section class="alignleft col-md-12">
<?php
$id = (int) $_GET['id'];

if (empty($id)) {
    echo '<meta http-equiv="refresh" content="0; url=error.php">';
}

$runq = mysqli_query($connect, "SELECT * FROM `posts` WHERE id='$id'");
if (mysqli_num_rows($runq) == 0) {
    echo '<meta http-equiv="refresh" content="0; url=error.php">';
}
$comuser = mysqli_query($connect, "SELECT * FROM `usertable`");
$row = mysqli_fetch_assoc($comuser);
$comuser2     = $row['name'];

mysqli_query($connect, "UPDATE `posts` SET views = views + 1 WHERE active='Yes' and id='$id'");
$row         = mysqli_fetch_assoc($runq);
$post_id     = $row['id'];
$runq3       = mysqli_query($connect, "SELECT * FROM `comments` WHERE post_id='$post_id' AND approved='Yes'");
$uNum        = mysqli_num_rows($runq3);
$category_id = $row['category_id'];
$runq4       = mysqli_query($connect, "SELECT * FROM `categories` WHERE id='$category_id'");
$cat         = mysqli_fetch_array($runq4);

    $run  = mysqli_query($connect, "SELECT * FROM `settings`");
    $site = mysqli_fetch_assoc($run);
?>




<!DOCTYPE html>
<html>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
        <title><?php
    echo $site['sitename'];
?></title>
        <meta name="description" content="<?php
    echo $site['description'];
?>" />
        <meta name="keywords" content="<?php
    echo $site['keywords'];
?>" />
        <meta name="author" content="Antonov_WEB" />
<meta name="robots" content="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="language" content="English">
<link href="https://fonts.googleapis.com/css2?family=Exo:wght@500&display=swap" rel="stylesheet">
<link href='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css' rel='stylesheet'>
<link href='https://use.fontawesome.com/releases/v5.7.2/css/all.css' rel='stylesheet'>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Exo:wght@500&display=swap');
</style>
<style>
html *
{
  font-family: 'Exo'
}

<style>.modal-dialog {
    height: 50%;
    width: 50%;
    margin: auto
}

.text1 {
    background-color: #dc3545;
    color: white;
    width: 35%;
    margin-top: 5%;
    text-align: center
}

.icon2 {
    color: #dc3545
}

.modal-header {
    color: white;
    background-color: #dc3545
}

.openmodal {
    margin-left: 35%;
    width: 25%;
    margin-top: 25%
}

</style>
                                </head>
                                <body oncontextmenu='return false' class='snippet-body'>
                                <!--Modal Launch Button-->
<button type="button" class="btn btn-info btn-lg openmodal" data-toggle="modal" data-target="#myModal">Open</button>
<!--Division for Modal-->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!--Modal Content-->
        <div class="modal-content">
            <!-- Modal Header-->
            <div class="modal-header">
                <h3><?php echo $row['title']; ?></h3>
                <!--Close/Cross Button--><button type="button" class="close" data-dismiss="modal" style="color: white;">&times;</button>
            </div> <!-- Modal Body-->
            <div class="modal-body">
                <div class="row">
                    <!--Gift Icon-->
                    <div class="col text-center"> <i class="fa fa-gift fa-4x icon2"></i></div>
                    <!--Modal Text-->
                    <div class="col-8">
                       <?php echo $row['content']; ?>
                        <h3 class="text1"><p id="sample"><?php echo $row['title2']; ?></p></h3>
                    </div>
                </div>
            </div> <!-- Modal Footer-->
            <div class="modal-footer"><a href="#" class="btn btn-danger" onclick="CopyToClipboard('sample');return false;">Copy Text  </a> <a href="" class="btn btn-outline-danger" data-dismiss="modal">Close</a> </div>
        </div>
    </div>
</div>
                                <script type='text/javascript' src='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js'></script>
                                <script type='text/javascript'></script>
<script>
function CopyToClipboard(id)
{
var r = document.createRange();
r.selectNode(document.getElementById(id));
window.getSelection().removeAllRanges();
window.getSelection().addRange(r);
document.execCommand('copy');
window.getSelection().removeAllRanges();
}
</script>
                    </article>
            </section>

			</div>
<?php
sidebar();
footer();
?>