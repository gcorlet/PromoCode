<?
include '../admin/config/database.php';

$id= $_GET['view'];
$query="SELECT * FROM home_content WHERE id=1";
$res= $conn->query($query);
$viewData=$res->fetch_assoc();
$backId=$viewData['id']-1;
$firstTitle=$viewData['first_title'];
$secondTitle=$viewData['second_title'];
$description=$viewData['description'];

$sql1="SELECT * FROM website_setting ORDER BY id DESC LIMIT 0,1";
$res1= $conn->query($sql1);
$data=$res1->fetch_assoc();
$id=!empty($data['id'])?$data['id']:'';
  $websiteTitle=!empty($data['website_title'])?$data['website_title']:'';
  $websiteName=!empty($data['website_name'])?$data['website_name']:'';
  $websiteName=!empty($data['website_name'])?$data['website_name']:'';
  $metaKeywords=!empty($data['meta_keyword'])?$data['meta_keyword']:'';
  $metaDescription=!empty($data['meta_description'])?$data['meta_description']:'';
  $copyright=!empty($data['google_varification_code'])?$data['google_varification_code']:'';
?>

<!DOCTYPE html>
<html>
<head>
<title><?php echo $websiteTitle; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?php echo $metaDescription; ?>">
<meta name="keywords" content="<?php echo $metaKeywords; ?>">
<meta name="robots" content="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="language" content="English">
<link href="https://fonts.googleapis.com/css2?family=Exo:wght@500&display=swap" rel="stylesheet">
<style>
@import url('https://fonts.googleapis.com/css2?family=Exo:wght@500&display=swap');
</style>
<style>
html *
{
  font-family: 'Exo'
}

.coupon {
  border: 5px dotted #616161;
  width: 100%;
  border-radius: 15px;
  margin: 0 auto;
  max-width: 300px;
  color: #414141;
}

.container {
  padding: 2px 16px;
  background-color: #D5D5D5;
  color: #414141;
}

.promo {
  background: #515151;
  color: #D77D00;
  padding: 3px;
}

.expire {
  color: green;
}

.copyright { margin-top: 50px; font-size: 12px; text-transform: uppercase; }
.copyright a { text-decoration: none; padding: 5px;background: #c0392b; color: #FFFFFF; }
.copyright a:hover { background: transparent; color: #c0392b; }
</style>
<style>
}
.textBox
{
  height:30px;
  width:300px;
}
button
{
  height:15px;
  width:125px;
  border-radius:8px;
  padding:10px;
  font-size:18px;
  height:52px;
}
</style>
</head>
<body>
<div class="coupon">
<div class="container">
<h2> 
<center><?php echo  $websiteName; ?></center></h2>
</div>
<div class="container" style="background-color:#8C8C8C">
<h2><b><font color="green">20% OFF</font></b></h2>
<p><?php echo $description; ?></p>
</div>
<div class="container">
<p><h2>Promo Code: <p id="p1"><span class="promo"><?php echo $firstTitle; ?></p></h2></span></p>
<p class="expire">Expires: <?php echo $secondTitle; ?></p><br>
<center><button onclick="copyToClipboard('#p1')">Copy Code</button></center>
</div>
</div>
<script src="https://kit.fontawesome.com/aa0bacc6a9.js" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
function copyToClipboard(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).text()).select();
  document.execCommand("copy");
  $temp.remove();
}
</script>
<div class="copyright"><center><b><?php echo $copyright; ?></div></center>
</body>
</html>